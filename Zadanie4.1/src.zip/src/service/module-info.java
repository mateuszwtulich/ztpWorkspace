module service {
    requires model;
    exports com.example.service;
}