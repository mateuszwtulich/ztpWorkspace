module model {
    exports com.example.model;
}