module client {
    requires model;
    requires service;
}